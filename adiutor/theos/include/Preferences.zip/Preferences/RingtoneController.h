
#import "PSDetailController.h"

@interface RingtoneController : PSDetailController

-(void)applicationWillSuspend;
-(void)viewDidAppear:(BOOL)arg1;
-(void)viewWillDisappear:(BOOL)arg1;
-(void)willBecomeActive;

@end