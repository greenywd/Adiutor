#import <Preferences/Preferences.h>

@interface @@PROJECTNAME@@ListController: PSListController {
}
@end

@implementation @@PROJECTNAME@@ListController
- (id)specifiers {
	if(_specifiers == nil) {
		_specifiers = [[self loadSpecifiersFromPlistName:@"@@PROJECTNAME@@" target:self] retain];
	}
	return _specifiers;
}
@end

// vim:ft=objc
